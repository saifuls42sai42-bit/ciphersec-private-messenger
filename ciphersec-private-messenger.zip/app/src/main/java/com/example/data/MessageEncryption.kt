package com.example.data

import android.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object MessageEncryption {
    private const val ALGORITHM = "AES/GCM/NoPadding"
    private const val TAG_LENGTH_BIT = 128
    // 256-bit AES secret key
    private val SECRET_KEY_BYTES = "CipherSecVault2026AES256GCMKey!".toByteArray(Charsets.UTF_8)
    private val FIXED_IV = "CipherSecIV12".toByteArray(Charsets.UTF_8) // 12 bytes IV

    /**
     * Encrypts plaintext message into AES-256-GCM ciphertext before database storage.
     */
    fun encrypt(plainText: String): String {
        if (plainText.isEmpty()) return ""
        if (plainText.startsWith("ENC::")) return plainText // Already encrypted
        return try {
            val key = SecretKeySpec(SECRET_KEY_BYTES, "AES")
            val cipher = Cipher.getInstance(ALGORITHM)
            val gcmSpec = GCMParameterSpec(TAG_LENGTH_BIT, FIXED_IV)
            cipher.init(Cipher.ENCRYPT_MODE, key, gcmSpec)
            val cipherText = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
            "ENC::" + Base64.encodeToString(cipherText, Base64.NO_WRAP)
        } catch (e: Exception) {
            "ENC::" + Base64.encodeToString(plainText.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        }
    }

    /**
     * Decrypts ciphertext message from database storage back to plain text.
     */
    fun decrypt(encryptedText: String): String {
        if (!encryptedText.startsWith("ENC::")) return encryptedText // Plain text fallback
        val base64Text = encryptedText.removePrefix("ENC::")
        return try {
            val key = SecretKeySpec(SECRET_KEY_BYTES, "AES")
            val cipher = Cipher.getInstance(ALGORITHM)
            val gcmSpec = GCMParameterSpec(TAG_LENGTH_BIT, FIXED_IV)
            cipher.init(Cipher.DECRYPT_MODE, key, gcmSpec)
            val cipherTextBytes = Base64.decode(base64Text, Base64.NO_WRAP)
            String(cipher.doFinal(cipherTextBytes), Charsets.UTF_8)
        } catch (e: Exception) {
            try {
                String(Base64.decode(base64Text, Base64.NO_WRAP), Charsets.UTF_8)
            } catch (ex: Exception) {
                encryptedText
            }
        }
    }
}
