package com.example.data

import android.content.Context
import androidx.room.*

class Converters {
    @TypeConverter
    fun fromUserRole(value: UserRole): String = value.name

    @TypeConverter
    fun toUserRole(value: String): UserRole = runCatching { UserRole.valueOf(value) }.getOrDefault(UserRole.TEAM_MEMBER)

    @TypeConverter
    fun fromChatType(value: ChatType): String = value.name

    @TypeConverter
    fun toChatType(value: String): ChatType = runCatching { ChatType.valueOf(value) }.getOrDefault(ChatType.DIRECT)

    @TypeConverter
    fun fromMediaType(value: MediaType): String = value.name

    @TypeConverter
    fun toMediaType(value: String): MediaType = runCatching { MediaType.valueOf(value) }.getOrDefault(MediaType.NONE)

    @TypeConverter
    fun fromMessageStatus(value: MessageStatus): String = value.name

    @TypeConverter
    fun toMessageStatus(value: String): MessageStatus = runCatching { MessageStatus.valueOf(value) }.getOrDefault(MessageStatus.READ)

    @TypeConverter
    fun fromLogSeverity(value: LogSeverity): String = value.name

    @TypeConverter
    fun toLogSeverity(value: String): LogSeverity = runCatching { LogSeverity.valueOf(value) }.getOrDefault(LogSeverity.INFO)
}

@Database(
    entities = [
        UserEntity::class,
        DeviceEntity::class,
        SessionEntity::class,
        MessageEntity::class,
        GroupEntity::class,
        GroupMemberEntity::class,
        CallEntity::class,
        CallLogEntity::class,
        VoiceMessageEntity::class,
        MediaFileEntity::class,
        DocumentEntity::class,
        NotificationEntity::class,
        AuditLogEntity::class,
        SecurityLogEntity::class,
        SettingsEntity::class,
        ChatEntity::class
    ],
    version = 3,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun chatDao(): ChatDao
    abstract fun messageDao(): MessageDao
    abstract fun callLogDao(): CallLogDao
    abstract fun securityLogDao(): SecurityLogDao
    abstract fun deviceDao(): DeviceDao
    abstract fun sessionDao(): SessionDao
    abstract fun groupDao(): GroupDao
    abstract fun groupMemberDao(): GroupMemberDao
    abstract fun callDao(): CallDao
    abstract fun voiceMessageDao(): VoiceMessageDao
    abstract fun mediaFileDao(): MediaFileDao
    abstract fun documentDao(): DocumentDao
    abstract fun notificationDao(): NotificationDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun settingsDao(): SettingsDao


    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ciphersec_messenger.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
