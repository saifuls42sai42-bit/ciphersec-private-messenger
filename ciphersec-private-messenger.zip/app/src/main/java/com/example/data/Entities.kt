package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UserRole {
    SUPER_ADMIN,
    TEAM_MEMBER
}

// 1. Users Table
@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val email: String,
    val passwordHash: String,
    val role: UserRole,
    val clearanceLevel: String,
    val avatarRes: String = "img_cyber_avatar1",
    val onlineStatus: Boolean = false,
    val lastSeenTimestamp: Long = System.currentTimeMillis(),
    val isSuspended: Boolean = false,
    val securityPin: String = "1234",
    val is2FaEnabled: Boolean = false,
    val totpSecret: String = "JBSWY3DPEHPK3PXP",
    val isBiometricEnabled: Boolean = true,
    val inactivityTimeoutMinutes: Int = 5,
    val blockRootedDevices: Boolean = false,
    val preventScreenshots: Boolean = true,
    val isCertificatePinningEnabled: Boolean = true
)

// 2. Devices Table
@Entity(tableName = "devices")
data class DeviceEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val deviceName: String,
    val deviceType: String, // e.g. "Android 14 Mobile", "Web Portal", "macOS Agent"
    val ipAddress: String,
    val lastActiveTimestamp: Long = System.currentTimeMillis(),
    val isVerified: Boolean = true,
    val isCurrentDevice: Boolean = false
)

// 3. Sessions Table
@Entity(tableName = "sessions")
data class SessionEntity(
    @PrimaryKey val sessionId: String,
    val userId: String,
    val deviceId: String,
    val authTokenHash: String,
    val ipAddress: String,
    val userAgent: String,
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val expiresAtTimestamp: Long = System.currentTimeMillis() + 86400000L * 30, // 30 days
    val isActive: Boolean = true
)

// 4. Messages Table (Every message is encrypted before storage)
enum class MediaType {
    NONE,
    IMAGE,
    VIDEO,
    DOCUMENT,
    PDF,
    VOICE
}

enum class MessageStatus {
    SENDING,
    SENT,
    DELIVERED,
    READ
}

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val chatId: String,
    val senderId: String,
    val senderName: String,
    val senderAvatar: String = "",
    val text: String, // Encrypted string in database (AES-256-GCM)
    val mediaType: MediaType = MediaType.NONE,
    val mediaUri: String = "",
    val durationMs: Long = 0,
    val fileName: String = "",
    val fileSize: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val status: MessageStatus = MessageStatus.READ,
    val replyToMessageId: String? = null,
    val replyToSenderName: String? = null,
    val replyToText: String? = null,
    val isEdited: Boolean = false,
    val isDeleted: Boolean = false,
    val isPinned: Boolean = false,
    val reactionsJson: String = "{}"
) {
    fun getDecryptedText(): String {
        return MessageEncryption.decrypt(text)
    }
}

// 5. Groups Table
@Entity(tableName = "groups")
data class GroupEntity(
    @PrimaryKey val groupId: String,
    val name: String,
    val description: String,
    val createdByUserId: String,
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val avatarRes: String = "ic_group_chat",
    val isEncryptedChannel: Boolean = true,
    val maxMembers: Int = 100
)

// 6. Group Members Table
@Entity(tableName = "group_members")
data class GroupMemberEntity(
    @PrimaryKey val id: String, // groupId_userId
    val groupId: String,
    val userId: String,
    val role: String = "MEMBER", // ADMIN, MEMBER, MODERATOR
    val joinedTimestamp: Long = System.currentTimeMillis()
)

// 7. Calls Table
@Entity(tableName = "calls")
data class CallEntity(
    @PrimaryKey val callId: String,
    val chatId: String,
    val callerUserId: String,
    val isVideoCall: Boolean = false,
    val isGroupCall: Boolean = false,
    val startTimeTimestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 0,
    val callStatus: String = "COMPLETED" // MISSED, COMPLETED, DECLINED
)

// Legacy alias / compatibility
@Entity(tableName = "call_logs")
data class CallLogEntity(
    @PrimaryKey val id: String,
    val chatId: String,
    val chatName: String,
    val callerName: String,
    val isGroup: Boolean,
    val isVideo: Boolean,
    val durationSeconds: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String
)

// 8. Voice Messages Table
@Entity(tableName = "voice_messages")
data class VoiceMessageEntity(
    @PrimaryKey val voiceId: String,
    val messageId: String,
    val fileUri: String,
    val durationSeconds: Int,
    val sampleRate: Int = 44100,
    val waveformPointsJson: String = "[10,25,45,80,60,30,15,50,90,40,20]",
    val createdAtTimestamp: Long = System.currentTimeMillis()
)

// 9. Media Files Table
@Entity(tableName = "media_files")
data class MediaFileEntity(
    @PrimaryKey val mediaId: String,
    val messageId: String,
    val fileUri: String,
    val mimeType: String,
    val width: Int = 0,
    val height: Int = 0,
    val sizeBytes: Long = 0,
    val sha256Checksum: String = "",
    val createdAtTimestamp: Long = System.currentTimeMillis()
)

// 10. Documents Table
@Entity(tableName = "documents")
data class DocumentEntity(
    @PrimaryKey val documentId: String,
    val messageId: String,
    val fileName: String,
    val fileExtension: String,
    val sizeBytes: Long,
    val storageUri: String,
    val encryptionHash: String = "SHA-256-AES",
    val uploadedAtTimestamp: Long = System.currentTimeMillis()
)

// 11. Notifications Table
@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val notificationId: String,
    val userId: String,
    val title: String,
    val body: String,
    val type: String = "SYSTEM_ALERT",
    val isRead: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

// 12. Audit Logs Table
enum class LogSeverity {
    INFO,
    WARNING,
    CRITICAL
}

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey val logId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val actorUserId: String,
    val actionType: String,
    val severity: LogSeverity,
    val details: String,
    val ipAddress: String = "127.0.0.1"
)

// Legacy alias / compatibility
@Entity(tableName = "security_logs")
data class SecurityLogEntity(
    @PrimaryKey val id: String,
    val timestamp: Long = System.currentTimeMillis(),
    val eventType: String,
    val severity: LogSeverity,
    val details: String,
    val ipAddress: String = "192.168.1.104"
)

// 13. Settings Table
@Entity(tableName = "settings")
data class SettingsEntity(
    @PrimaryKey val key: String,
    val value: String,
    val category: String = "GENERAL",
    val lastUpdatedTimestamp: Long = System.currentTimeMillis()
)

enum class ChatType {
    DIRECT,
    GROUP
}

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey val id: String,
    val type: ChatType,
    val name: String,
    val description: String = "",
    val avatarRes: String = "",
    val memberIdsJson: String,
    val lastMessageText: String = "",
    val lastMessageTimestamp: Long = System.currentTimeMillis(),
    val unreadCount: Int = 0,
    val isPinned: Boolean = false,
    val isMuted: Boolean = false,
    val encryptionKeyHash: String = "AES-256-GCM-SHA512"
)

