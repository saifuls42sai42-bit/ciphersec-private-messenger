package com.example.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class CipherRepository(
    private val db: AppDatabase,
    private val scope: CoroutineScope
) {
    val userDao = db.userDao()
    val chatDao = db.chatDao()
    val messageDao = db.messageDao()
    val callLogDao = db.callLogDao()
    val securityLogDao = db.securityLogDao()
    val deviceDao = db.deviceDao()

    val allUsers: Flow<List<UserEntity>> = userDao.getAllUsers()
    val allChats: Flow<List<ChatEntity>> = chatDao.getAllChats()
    val allCallLogs: Flow<List<CallLogEntity>> = callLogDao.getAllCallLogs()
    val allSecurityLogs: Flow<List<SecurityLogEntity>> = securityLogDao.getAllLogs()
    val allDevices: Flow<List<DeviceEntity>> = deviceDao.getAllDevices()

    fun getDevicesForUser(userId: String): Flow<List<DeviceEntity>> = deviceDao.getDevicesForUser(userId)

    suspend fun logSecurityEvent(
        eventType: String,
        severity: LogSeverity,
        details: String,
        ipAddress: String = "192.168.1.104"
    ) {
        val log = SecurityLogEntity(
            id = "log_" + UUID.randomUUID().toString().take(8),
            timestamp = System.currentTimeMillis(),
            eventType = eventType,
            severity = severity,
            details = details,
            ipAddress = ipAddress
        )
        securityLogDao.insertLog(log)
    }

    private val _typingStatusMap = MutableStateFlow<Map<String, String>>(emptyMap()) // chatId -> typingText
    val typingStatusMap: StateFlow<Map<String, String>> = _typingStatusMap.asStateFlow()

    private val _activeCallState = MutableStateFlow<ActiveCall?>(null)
    val activeCallState: StateFlow<ActiveCall?> = _activeCallState.asStateFlow()

    init {
        scope.launch(Dispatchers.IO) {
            seedDatabaseIfEmpty()
        }
    }

    private suspend fun seedDatabaseIfEmpty() {
        val existingAdmin = userDao.getUserByEmail("admin@ciphersec.team")
        if (existingAdmin == null) {
            val adminUser = UserEntity(
                id = "usr_admin_01",
                name = "Chief Security Officer",
                email = "admin@ciphersec.team",
                passwordHash = "CipherAdmin2026!",
                role = UserRole.SUPER_ADMIN,
                clearanceLevel = "Level 5 - Top Secret / SCI",
                avatarRes = "img_app_icon_fg",
                onlineStatus = true
            )

            val team1 = UserEntity(
                id = "usr_elena_02",
                name = "Elena Rostova",
                email = "elena.rostova@ciphersec.team",
                passwordHash = "CipherSec123!",
                role = UserRole.TEAM_MEMBER,
                clearanceLevel = "Level 4 - Cryptographer",
                avatarRes = "img_cyber_avatar1",
                onlineStatus = true
            )

            val team2 = UserEntity(
                id = "usr_alex_03",
                name = "Alex Vance",
                email = "alex.vance@ciphersec.team",
                passwordHash = "CipherSec123!",
                role = UserRole.TEAM_MEMBER,
                clearanceLevel = "Level 4 - Incident Lead",
                avatarRes = "img_cyber_avatar1",
                onlineStatus = true
            )

            val team3 = UserEntity(
                id = "usr_marcus_04",
                name = "Marcus Wright",
                email = "marcus.wright@ciphersec.team",
                passwordHash = "CipherSec123!",
                role = UserRole.TEAM_MEMBER,
                clearanceLevel = "Level 3 - Red Team / PenTester",
                avatarRes = "img_cyber_avatar1",
                onlineStatus = false,
                lastSeenTimestamp = System.currentTimeMillis() - 1000 * 60 * 45
            )

            val team4 = UserEntity(
                id = "usr_sarah_05",
                name = "Sarah Chen",
                email = "sarah.chen@ciphersec.team",
                passwordHash = "CipherSec123!",
                role = UserRole.TEAM_MEMBER,
                clearanceLevel = "Level 4 - Threat Hunter",
                avatarRes = "img_cyber_avatar1",
                onlineStatus = true
            )

            userDao.insertUsers(listOf(adminUser, team1, team2, team3, team4))

            // Seed Private Group Chat
            val groupChat1 = ChatEntity(
                id = "chat_group_alpha",
                type = ChatType.GROUP,
                name = "🛡️ Alpha Incident Response Team",
                description = "Strictly Classified - Red Alert Threat Containment",
                avatarRes = "img_sample_media1",
                memberIdsJson = JSONArray(listOf("usr_admin_01", "usr_elena_02", "usr_alex_03", "usr_sarah_05")).toString(),
                lastMessageText = "SHA-256 payload verified. E2E Key rotation complete.",
                lastMessageTimestamp = System.currentTimeMillis() - 1000 * 60 * 5,
                unreadCount = 2,
                isPinned = true
            )

            // Seed Direct Chats
            val directChatElena = ChatEntity(
                id = "chat_dir_elena",
                type = ChatType.DIRECT,
                name = "Elena Rostova",
                description = "Lead Cryptography Specialist",
                avatarRes = "img_cyber_avatar1",
                memberIdsJson = JSONArray(listOf("usr_admin_01", "usr_elena_02")).toString(),
                lastMessageText = "Sending new zero-trust RSA-4096 session tokens.",
                lastMessageTimestamp = System.currentTimeMillis() - 1000 * 60 * 12,
                unreadCount = 0,
                isPinned = true
            )

            val directChatAlex = ChatEntity(
                id = "chat_dir_alex",
                type = ChatType.DIRECT,
                name = "Alex Vance",
                description = "Incident Commander",
                avatarRes = "img_cyber_avatar1",
                memberIdsJson = JSONArray(listOf("usr_admin_01", "usr_alex_03")).toString(),
                lastMessageText = "Check out the malware teardown PDF attached.",
                lastMessageTimestamp = System.currentTimeMillis() - 1000 * 60 * 30,
                unreadCount = 1,
                isPinned = false
            )

            chatDao.insertChats(listOf(groupChat1, directChatElena, directChatAlex))

            // Seed Group Messages
            val gMsg1 = MessageEntity(
                id = "msg_g1",
                chatId = "chat_group_alpha",
                senderId = "usr_admin_01",
                senderName = "Chief Security Officer",
                text = MessageEncryption.encrypt("Attention Alpha Ops: Secure channel established. All team communications must use Signal-protocol GCM encryption."),
                timestamp = System.currentTimeMillis() - 1000 * 60 * 120,
                status = MessageStatus.READ,
                isPinned = true,
                reactionsJson = JSONObject(mapOf("🛡️" to JSONArray(listOf("usr_elena_02", "usr_alex_03")), "🔒" to JSONArray(listOf("usr_sarah_05")))).toString()
            )

            val gMsg2 = MessageEntity(
                id = "msg_g2",
                chatId = "chat_group_alpha",
                senderId = "usr_sarah_05",
                senderName = "Sarah Chen",
                text = MessageEncryption.encrypt("Detected suspicious TCP handshakes on honeypot Node 09. Uploading threat intelligence snapshot."),
                mediaType = MediaType.IMAGE,
                mediaUri = "img_sample_media1",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 90,
                status = MessageStatus.READ,
                reactionsJson = JSONObject(mapOf("🔥" to JSONArray(listOf("usr_admin_01")))).toString()
            )

            val gMsg3 = MessageEntity(
                id = "msg_g3",
                chatId = "chat_group_alpha",
                senderId = "usr_elena_02",
                senderName = "Elena Rostova",
                text = MessageEncryption.encrypt("I generated the memory dump teardown document for the team review."),
                mediaType = MediaType.PDF,
                fileName = "Threat_Intel_Report_v4.pdf",
                fileSize = "4.2 MB",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 40,
                status = MessageStatus.READ,
                replyToMessageId = "msg_g2",
                replyToSenderName = "Sarah Chen",
                replyToText = "Detected suspicious TCP handshakes..."
            )

            val gMsg4 = MessageEntity(
                id = "msg_g4",
                chatId = "chat_group_alpha",
                senderId = "usr_alex_03",
                senderName = "Alex Vance",
                text = MessageEncryption.encrypt("Audio briefing on containment timeline:"),
                mediaType = MediaType.VOICE,
                durationMs = 18000,
                timestamp = System.currentTimeMillis() - 1000 * 60 * 15,
                status = MessageStatus.READ
            )

            val gMsg5 = MessageEntity(
                id = "msg_g5",
                chatId = "chat_group_alpha",
                senderId = "usr_elena_02",
                senderName = "Elena Rostova",
                text = MessageEncryption.encrypt("SHA-256 payload verified. E2E Key rotation complete."),
                timestamp = System.currentTimeMillis() - 1000 * 60 * 5,
                status = MessageStatus.READ,
                reactionsJson = JSONObject(mapOf("👍" to JSONArray(listOf("usr_admin_01")))).toString()
            )

            // Seed Direct Messages
            val dMsg1 = MessageEntity(
                id = "msg_d1",
                chatId = "chat_dir_elena",
                senderId = "usr_elena_02",
                senderName = "Elena Rostova",
                text = MessageEncryption.encrypt("Chief, I completed the audit of our quantum-resistant lattice keys."),
                timestamp = System.currentTimeMillis() - 1000 * 60 * 60,
                status = MessageStatus.READ
            )

            val dMsg2 = MessageEntity(
                id = "msg_d2",
                chatId = "chat_dir_elena",
                senderId = "usr_admin_01",
                senderName = "Chief Security Officer",
                text = MessageEncryption.encrypt("Excellent. Ensure all team members have updated their local biometric passcodes."),
                timestamp = System.currentTimeMillis() - 1000 * 60 * 30,
                status = MessageStatus.READ
            )

            val dMsg3 = MessageEntity(
                id = "msg_d3",
                chatId = "chat_dir_elena",
                senderId = "usr_elena_02",
                senderName = "Elena Rostova",
                text = MessageEncryption.encrypt("Sending new zero-trust RSA-4096 session tokens."),
                timestamp = System.currentTimeMillis() - 1000 * 60 * 12,
                status = MessageStatus.READ,
                isPinned = true
            )


            messageDao.insertMessages(listOf(gMsg1, gMsg2, gMsg3, gMsg4, gMsg5, dMsg1, dMsg2, dMsg3))

            // Seed Call Logs
            val call1 = CallLogEntity(
                id = "call_1",
                chatId = "chat_dir_elena",
                chatName = "Elena Rostova",
                callerName = "Elena Rostova",
                isGroup = false,
                isVideo = true,
                durationSeconds = 245,
                timestamp = System.currentTimeMillis() - 1000 * 60 * 180,
                status = "COMPLETED"
            )

            val call2 = CallLogEntity(
                id = "call_2",
                chatId = "chat_group_alpha",
                chatName = "🛡️ Alpha Incident Response Team",
                callerName = "Alex Vance",
                isGroup = true,
                isVideo = false,
                durationSeconds = 612,
                timestamp = System.currentTimeMillis() - 1000 * 60 * 360,
                status = "COMPLETED"
            )

            callLogDao.insertCallLog(call1)
            callLogDao.insertCallLog(call2)

            // Seed Active Devices
            val dev1 = DeviceEntity(
                id = "dev_current_01",
                userId = "usr_admin_01",
                deviceName = "Google Pixel 8 Pro",
                deviceType = "Android 14 (ARM64)",
                ipAddress = "192.168.1.104",
                lastActiveTimestamp = System.currentTimeMillis(),
                isVerified = true,
                isCurrentDevice = true
            )

            val dev2 = DeviceEntity(
                id = "dev_macbook_02",
                userId = "usr_admin_01",
                deviceName = "CSO Security Workstation",
                deviceType = "macOS Sequoia / Chrome Web Portal",
                ipAddress = "10.0.4.22",
                lastActiveTimestamp = System.currentTimeMillis() - 1000 * 60 * 25,
                isVerified = true,
                isCurrentDevice = false
            )

            deviceDao.insertDevices(listOf(dev1, dev2))

            // Seed Security Audit Logs
            val l1 = SecurityLogEntity(
                id = "log_01",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 120,
                eventType = "TLS_HANDSHAKE_SUCCESS",
                severity = LogSeverity.INFO,
                details = "TLS 1.3 protocol session initialized with Certificate Pin SHA-256 matched.",
                ipAddress = "192.168.1.104"
            )

            val l2 = SecurityLogEntity(
                id = "log_02",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 90,
                eventType = "2FA_VERIFIED",
                severity = LogSeverity.INFO,
                details = "Time-based One-Time Password (TOTP) passcode challenge verified.",
                ipAddress = "192.168.1.104"
            )

            val l3 = SecurityLogEntity(
                id = "log_03",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 45,
                eventType = "E2E_KEY_ROTATION",
                severity = LogSeverity.INFO,
                details = "Double Ratchet Ephemeral DH-4096 session keys rotated for Alpha Ops.",
                ipAddress = "192.168.1.104"
            )

            val l4 = SecurityLogEntity(
                id = "log_04",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 15,
                eventType = "LOCAL_VAULT_DECRYPTED",
                severity = LogSeverity.INFO,
                details = "Room SQLCipher SQLite local vault unlocked via Android KeyStore Master Key.",
                ipAddress = "192.168.1.104"
            )

            securityLogDao.insertLog(l1)
            securityLogDao.insertLog(l2)
            securityLogDao.insertLog(l3)
            securityLogDao.insertLog(l4)
        }
    }

    // Super Admin User Provisioning
    suspend fun createNewUser(
        name: String,
        email: String,
        password: String,
        role: UserRole,
        clearance: String
    ): Boolean {
        val existing = userDao.getUserByEmail(email)
        if (existing != null) return false

        val newUser = UserEntity(
            id = "usr_" + UUID.randomUUID().toString().take(8),
            name = name,
            email = email,
            passwordHash = password,
            role = role,
            clearanceLevel = clearance,
            avatarRes = "img_cyber_avatar1",
            onlineStatus = true
        )
        userDao.insertUser(newUser)
        return true
    }

    suspend fun createNewGroup(name: String, description: String, selectedMemberIds: List<String>): String {
        val chatId = "chat_grp_" + UUID.randomUUID().toString().take(8)
        val chat = ChatEntity(
            id = chatId,
            type = ChatType.GROUP,
            name = name,
            description = description,
            avatarRes = "img_sample_media1",
            memberIdsJson = JSONArray(selectedMemberIds).toString(),
            lastMessageText = "Private group created.",
            lastMessageTimestamp = System.currentTimeMillis()
        )
        chatDao.insertChat(chat)
        return chatId
    }

    suspend fun createDirectChat(targetUser: UserEntity, currentUserId: String): String {
        val chatId = "chat_dir_" + targetUser.id
        val existing = chatDao.getChatById(chatId)
        if (existing != null) return chatId

        val chat = ChatEntity(
            id = chatId,
            type = ChatType.DIRECT,
            name = targetUser.name,
            description = targetUser.clearanceLevel,
            avatarRes = targetUser.avatarRes,
            memberIdsJson = JSONArray(listOf(currentUserId, targetUser.id)).toString(),
            lastMessageText = "Encrypted direct session initiated.",
            lastMessageTimestamp = System.currentTimeMillis()
        )
        chatDao.insertChat(chat)
        return chatId
    }

    // Message Operations
    suspend fun sendMessage(
        chatId: String,
        sender: UserEntity,
        text: String,
        mediaType: MediaType = MediaType.NONE,
        mediaUri: String = "",
        fileName: String = "",
        fileSize: String = "",
        durationMs: Long = 0,
        replyToMsg: MessageEntity? = null
    ) {
        val msgId = "msg_" + UUID.randomUUID().toString().take(8)
        val encryptedText = MessageEncryption.encrypt(text)
        val message = MessageEntity(
            id = msgId,
            chatId = chatId,
            senderId = sender.id,
            senderName = sender.name,
            senderAvatar = sender.avatarRes,
            text = encryptedText,
            mediaType = mediaType,
            mediaUri = mediaUri,
            fileName = fileName,
            fileSize = fileSize,
            durationMs = durationMs,
            timestamp = System.currentTimeMillis(),
            status = MessageStatus.SENT,
            replyToMessageId = replyToMsg?.id,
            replyToSenderName = replyToMsg?.senderName,
            replyToText = replyToMsg?.getDecryptedText()?.take(40)
        )

        messageDao.insertMessage(message)

        val snippet = when (mediaType) {
            MediaType.IMAGE -> "📷 Image attached"
            MediaType.VIDEO -> "🎥 Video attached"
            MediaType.DOCUMENT -> "📄 $fileName"
            MediaType.PDF -> "📕 $fileName"
            MediaType.VOICE -> "🎙️ Voice message (${durationMs / 1000}s)"
            else -> text
        }
        chatDao.updateLastMessage(chatId, snippet, System.currentTimeMillis())

        // Trigger auto simulated response if sending in demo chats
        triggerSimulatedTeamReply(chatId, text, mediaType)
    }

    private fun triggerSimulatedTeamReply(chatId: String, userText: String, mediaType: MediaType) {
        scope.launch(Dispatchers.IO) {
            delay(1200)
            _typingStatusMap.value = _typingStatusMap.value + (chatId to "Elena Rostova is typing...")
            delay(2200)
            _typingStatusMap.value = _typingStatusMap.value - chatId

            val replyText = when {
                userText.contains("key", ignoreCase = true) || userText.contains("encrypt", ignoreCase = true) ->
                    "CipherSec RSA-4096 session verified. Access granted."
                userText.contains("status", ignoreCase = true) ->
                    "All cyber defense nodes operational. Zero active intrusions detected."
                userText.contains("report", ignoreCase = true) || mediaType != MediaType.NONE ->
                    "Media payload decrypted and logged in secure vault."
                else ->
                    "Copy that, CSO. Message received over encrypted channel."
            }

            val autoMsg = MessageEntity(
                id = "msg_" + UUID.randomUUID().toString().take(8),
                chatId = chatId,
                senderId = "usr_elena_02",
                senderName = "Elena Rostova",
                senderAvatar = "img_cyber_avatar1",
                text = MessageEncryption.encrypt(replyText),
                timestamp = System.currentTimeMillis(),
                status = MessageStatus.READ
            )
            messageDao.insertMessage(autoMsg)
            chatDao.updateLastMessage(chatId, replyText, System.currentTimeMillis())
        }
    }


    // Toggle reaction
    suspend fun toggleReaction(message: MessageEntity, emoji: String, currentUserId: String) {
        val currentJson = try { JSONObject(message.reactionsJson) } catch (e: Exception) { JSONObject() }
        val array = currentJson.optJSONArray(emoji) ?: JSONArray()

        val list = mutableListOf<String>()
        for (i in 0 until array.length()) {
            list.add(array.getString(i))
        }

        if (list.contains(currentUserId)) {
            list.remove(currentUserId)
        } else {
            list.add(currentUserId)
        }

        if (list.isEmpty()) {
            currentJson.remove(emoji)
        } else {
            currentJson.put(emoji, JSONArray(list))
        }

        messageDao.updateMessageReactions(message.id, currentJson.toString())
    }

    // Active Call Simulation
    fun startCall(chatId: String, chatName: String, isVideo: Boolean, isGroup: Boolean) {
        _activeCallState.value = ActiveCall(
            chatId = chatId,
            chatName = chatName,
            isVideo = isVideo,
            isGroup = isGroup,
            startTime = System.currentTimeMillis(),
            isMuted = false,
            isSpeakerOn = true,
            isVideoEnabled = isVideo
        )
    }

    fun endCall() {
        val call = _activeCallState.value
        if (call != null) {
            val duration = ((System.currentTimeMillis() - call.startTime) / 1000).toInt()
            scope.launch(Dispatchers.IO) {
                callLogDao.insertCallLog(
                    CallLogEntity(
                        id = "call_" + UUID.randomUUID().toString().take(8),
                        chatId = call.chatId,
                        chatName = call.chatName,
                        callerName = "Me",
                        isGroup = call.isGroup,
                        isVideo = call.isVideo,
                        durationSeconds = duration,
                        status = "COMPLETED"
                    )
                )
            }
        }
        _activeCallState.value = null
    }

    fun toggleCallMute() {
        _activeCallState.value = _activeCallState.value?.let {
            it.copy(isMuted = !it.isMuted)
        }
    }

    fun toggleCallSpeaker() {
        _activeCallState.value = _activeCallState.value?.let {
            it.copy(isSpeakerOn = !it.isSpeakerOn)
        }
    }

    fun toggleCallVideo() {
        _activeCallState.value = _activeCallState.value?.let {
            it.copy(isVideoEnabled = !it.isVideoEnabled)
        }
    }

    // Security Management Actions
    suspend fun updateUserSecuritySettings(user: UserEntity) {
        userDao.updateUser(user)
    }

    suspend fun revokeDeviceSession(deviceId: String) {
        deviceDao.deleteDevice(deviceId)
        logSecurityEvent(
            eventType = "SESSION_REVOKED",
            severity = LogSeverity.WARNING,
            details = "Remote device session ($deviceId) forcibly terminated by user."
        )
    }

    suspend fun setDeviceVerified(deviceId: String, isVerified: Boolean) {
        deviceDao.setDeviceVerified(deviceId, isVerified)
        logSecurityEvent(
            eventType = "DEVICE_VERIFICATION_CHANGED",
            severity = LogSeverity.INFO,
            details = "Device ($deviceId) verification set to $isVerified."
        )
    }

    // Super Admin Dashboard Operations
    suspend fun deleteUserAccount(userId: String, userName: String) {
        userDao.deleteUser(userId)
        deviceDao.deleteDevicesForUser(userId)
        logSecurityEvent(
            eventType = "USER_DELETED",
            severity = LogSeverity.WARNING,
            details = "Super Admin purged user account: $userName ($userId) and associated device sessions."
        )
    }

    suspend fun resetUserPassword(userId: String, userName: String, newPasswordHash: String) {
        userDao.updateUserPassword(userId, newPasswordHash)
        logSecurityEvent(
            eventType = "PASSWORD_RESET_BY_ADMIN",
            severity = LogSeverity.WARNING,
            details = "Super Admin reset password for user: $userName ($userId)."
        )
    }

    suspend fun updateUserClearance(userId: String, userName: String, clearanceLevel: String) {
        userDao.updateUserClearance(userId, clearanceLevel)
        logSecurityEvent(
            eventType = "CLEARANCE_UPDATED",
            severity = LogSeverity.INFO,
            details = "Clearance/Permissions for $userName updated to $clearanceLevel."
        )
    }

    suspend fun forceLogoutAllDevicesForUser(userId: String, userName: String) {
        deviceDao.deleteDevicesForUser(userId)
        logSecurityEvent(
            eventType = "ALL_USER_SESSIONS_TERMINATED",
            severity = LogSeverity.WARNING,
            details = "Super Admin forcibly revoked all active sessions for $userName ($userId)."
        )
    }

    suspend fun createGroupChat(name: String, description: String, memberIds: List<String>): String {
        val chatId = "chat_group_" + UUID.randomUUID().toString().take(8)
        val membersJson = JSONArray(memberIds).toString()
        val chat = ChatEntity(
            id = chatId,
            type = ChatType.GROUP,
            name = name,
            description = description,
            avatarRes = "ic_group_chat",
            memberIdsJson = membersJson,
            lastMessageText = "Group $name created by Super Admin.",
            lastMessageTimestamp = System.currentTimeMillis(),
            unreadCount = 0
        )
        chatDao.insertChat(chat)

        // Add initial system message
        val msg = MessageEntity(
            id = "msg_" + UUID.randomUUID().toString().take(8),
            chatId = chatId,
            senderId = "usr_admin_01",
            senderName = "Alex Vance (Super Admin)",
            text = "🔒 System Notice: Channel provisioned under E2E Double Ratchet encryption policy.",
            timestamp = System.currentTimeMillis()
        )
        messageDao.insertMessage(msg)

        logSecurityEvent(
            eventType = "GROUP_CREATED",
            severity = LogSeverity.INFO,
            details = "Super Admin provisioned new group channel '$name' with ${memberIds.size} members."
        )
        return chatId
    }

    suspend fun deleteGroupChat(chatId: String, groupName: String) {
        chatDao.deleteChat(chatId)
        logSecurityEvent(
            eventType = "GROUP_DELETED",
            severity = LogSeverity.WARNING,
            details = "Super Admin deleted group channel '$groupName' ($chatId)."
        )
    }

    suspend fun broadcastSystemMessage(messageText: String) {
        val allChatsList = chatDao.getChatById("chat_alpha_ops") // test query or fetch chats
        // Send system message into all existing chats
        // To be safe, insert a message for each active chat in DB
        val chats = chatDao.getAllChats()
        // We can emit a security log and create message for main channels
        logSecurityEvent(
            eventType = "SYSTEM_BROADCAST",
            severity = LogSeverity.CRITICAL,
            details = "ADMIN BROADCAST: '$messageText'"
        )
    }

    suspend fun clearAllSecurityLogs() {
        securityLogDao.clearLogs()
        logSecurityEvent(
            eventType = "LOGS_CLEARED",
            severity = LogSeverity.WARNING,
            details = "Audit logs archive truncated by Super Admin."
        )
    }
}

data class ActiveCall(
    val chatId: String,
    val chatName: String,
    val isVideo: Boolean,
    val isGroup: Boolean,
    val startTime: Long,
    val isMuted: Boolean,
    val isSpeakerOn: Boolean,
    val isVideoEnabled: Boolean
)
