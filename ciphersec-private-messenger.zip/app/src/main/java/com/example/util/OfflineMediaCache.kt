package com.example.util

import android.graphics.Bitmap
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object OfflineMediaCache {
    // 16MB LruCache for fast image thumbnail loading in Compose
    private val maxMemory = (Runtime.getRuntime().maxMemory() / 1024).toInt()
    private val cacheSize = maxMemory / 8 // Use 1/8th of available memory
    private val memoryCache = object : LruCache<String, Bitmap>(cacheSize) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int {
            return bitmap.byteCount / 1024
        }
    }

    fun getBitmapFromMemCache(key: String): Bitmap? {
        return memoryCache.get(key)
    }

    fun addBitmapToMemoryCache(key: String, bitmap: Bitmap) {
        if (getBitmapFromMemCache(key) == null) {
            memoryCache.put(key, bitmap)
        }
    }

    suspend fun preloadEncryptedCache(chatId: String): Boolean = withContext(Dispatchers.IO) {
        // Simulates rapid pre-fetching and local caching of encrypted chat media
        kotlinx.coroutines.delay(100)
        true
    }

    fun clearCache() {
        memoryCache.evictAll()
    }
}
