package com.example.util

import android.content.Context
import android.util.Log
import com.example.data.AppDatabase
import com.example.data.AuditLogEntity
import com.example.data.LogSeverity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID

object CrashRecoveryHandler {
    private var defaultHandler: Thread.UncaughtExceptionHandler? = null

    fun initialize(context: Context) {
        defaultHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e("CrashRecoveryHandler", "Fatal exception trapped on thread ${thread.name}", throwable)

            // Persist crash log into Room database before terminating or recovering
            try {
                val db = AppDatabase.getDatabase(context)
                CoroutineScope(Dispatchers.IO).launch {
                    db.auditLogDao().insertAuditLog(
                        AuditLogEntity(
                            logId = "crash_" + UUID.randomUUID().toString().take(8),
                            timestamp = System.currentTimeMillis(),
                            actorUserId = "SYSTEM_CRASH_HANDLER",
                            actionType = "UNCAUGHT_EXCEPTION_RECOVERED",
                            severity = LogSeverity.CRITICAL,
                            details = "Trapped fatal crash: ${throwable.localizedMessage ?: throwable.toString()}",
                            ipAddress = "127.0.0.1"
                        )
                    )
                }
            } catch (e: Exception) {
                Log.e("CrashRecoveryHandler", "Failed to save crash log", e)
            }

            // Delegate to system default handler to ensure proper cleanup if unrecoverable
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }
}
