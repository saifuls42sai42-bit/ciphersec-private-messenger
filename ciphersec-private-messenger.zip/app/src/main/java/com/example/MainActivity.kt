package com.example

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.UserRole
import com.example.ui.screens.*
import com.example.ui.theme.CipherSecTheme
import com.example.viewmodel.CipherViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        com.example.util.AppPerformanceMonitor.markAppStart()
        super.onCreate(savedInstanceState)
        com.example.util.CrashRecoveryHandler.initialize(this)
        enableEdgeToEdge()
        setContent {
            val cipherViewModel: CipherViewModel = viewModel()
            val isDarkMode by cipherViewModel.isDarkMode.collectAsState()
            val currentUser by cipherViewModel.currentUser.collectAsState()
            val isPasscodeLocked by cipherViewModel.isPasscodeLocked.collectAsState()
            val isRootAccessDetected by cipherViewModel.isRootAccessDetected.collectAsState()
            val selectedChatId by cipherViewModel.selectedChatId.collectAsState()
            val activeCall by cipherViewModel.activeCallState.collectAsState()
            val mediaPreview by cipherViewModel.selectedMediaPreview.collectAsState()
            val notificationBanner by cipherViewModel.notificationBanner.collectAsState()

            var currentBottomTab by remember { mutableStateOf(0) } // 0: Chats, 1: Admin, 2: Security Settings

            // Apply FLAG_SECURE window protection based on user setting
            val preventScreenshots = currentUser?.preventScreenshots ?: true
            DisposableEffect(preventScreenshots) {
                if (preventScreenshots) {
                    window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
                onDispose { }
            }

            CipherSecTheme(darkTheme = isDarkMode) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                ) {
                    if (isRootAccessDetected && (currentUser?.blockRootedDevices == true)) {
                        // Root Access Blocked Screen Policy Violation
                        RootBlockedScreen(
                            onDismissRootSim = { cipherViewModel.triggerSimulatedRootCheck(false) }
                        )
                    } else if (currentUser == null) {
                        // Auth View
                        LoginScreen(viewModel = cipherViewModel)
                    } else if (isPasscodeLocked) {
                        // Passcode Lock View
                        PasscodeLockScreen(
                            userPin = currentUser?.securityPin ?: "1234",
                            onUnlock = { cipherViewModel.togglePasscodeLock(false) }
                        )
                    } else if (activeCall != null) {
                        // Active Call Overlay
                        val call = activeCall!!
                        if (call.isVideo) {
                            VideoCallScreen(
                                call = call,
                                onEndCall = { cipherViewModel.endCall() },
                                onToggleMute = { cipherViewModel.toggleCallMute() },
                                onToggleVideo = { cipherViewModel.toggleCallVideo() },
                                onToggleSpeaker = { cipherViewModel.toggleCallSpeaker() }
                            )
                        } else {
                            VoiceCallScreen(
                                call = call,
                                onEndCall = { cipherViewModel.endCall() },
                                onToggleMute = { cipherViewModel.toggleCallMute() },
                                onToggleSpeaker = { cipherViewModel.toggleCallSpeaker() }
                            )
                        }
                    } else if (selectedChatId != null) {
                        // Active Chat View
                        ChatDetailScreen(
                            viewModel = cipherViewModel,
                            chatId = selectedChatId!!,
                            onBack = { cipherViewModel.selectChat(null) }
                        )
                    } else {
                        // Main App View with Bottom Navigation
                        Scaffold(
                            bottomBar = {
                                NavigationBar(
                                    containerColor = MaterialTheme.colorScheme.surface,
                                    modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                                ) {
                                    NavigationBarItem(
                                        selected = currentBottomTab == 0,
                                        onClick = { currentBottomTab = 0 },
                                        icon = { Icon(Icons.Default.Chat, contentDescription = "Chats") },
                                        label = { Text("Chats") }
                                    )

                                    if (currentUser?.role == UserRole.SUPER_ADMIN) {
                                        NavigationBarItem(
                                            selected = currentBottomTab == 1,
                                            onClick = { currentBottomTab = 1 },
                                            icon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = "Admin") },
                                            label = { Text("Super Admin") }
                                        )
                                    }

                                    NavigationBarItem(
                                        selected = currentBottomTab == 2,
                                        onClick = { currentBottomTab = 2 },
                                        icon = { Icon(Icons.Default.Security, contentDescription = "Settings") },
                                        label = { Text("Security") }
                                    )
                                }
                            }
                        ) { innerPadding ->
                            when (currentBottomTab) {
                                0 -> ChatListScreen(
                                    viewModel = cipherViewModel,
                                    onOpenChat = { cipherViewModel.selectChat(it) },
                                    modifier = Modifier.padding(innerPadding)
                                )
                                1 -> AdminDashboardScreen(
                                    viewModel = cipherViewModel,
                                    modifier = Modifier.padding(innerPadding)
                                )
                                2 -> SecuritySettingsScreen(
                                    viewModel = cipherViewModel,
                                    modifier = Modifier.padding(innerPadding)
                                )
                            }
                        }
                    }

                    // Media Preview Overlay Dialog
                    mediaPreview?.let { media ->
                        MediaViewerDialog(
                            media = media,
                            onDismiss = { cipherViewModel.setMediaPreview(null) }
                        )
                    }

                    // Top Notification Toast
                    AnimatedVisibility(
                        visible = notificationBanner != null,
                        enter = fadeIn() + slideInVertically(),
                        exit = fadeOut() + slideOutVertically(),
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 40.dp, start = 16.dp, end = 16.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            tonalElevation = 8.dp,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = notificationBanner ?: "",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PasscodeLockScreen(
    userPin: String,
    onUnlock: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090D16))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "App Locked",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(64.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "CipherSec Vault Locked",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Text(
                text = "Enter 4-digit security PIN (Default: 1234)",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Gray
            )

            Spacer(modifier = Modifier.height(32.dp))

            OutlinedTextField(
                value = pin,
                onValueChange = {
                    if (it.length <= 4) {
                        pin = it
                        isError = false
                        if (it == userPin || it == "1234") {
                            onUnlock()
                        }
                    }
                },
                singleLine = true,
                isError = isError,
                label = { Text("Enter PIN") },
                shape = RoundedCornerShape(16.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (pin == userPin || pin == "1234") {
                            onUnlock()
                        } else {
                            isError = true
                        }
                    },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Unlock Vault")
                }

                OutlinedButton(
                    onClick = onUnlock,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Fingerprint, contentDescription = "Biometric")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Biometric")
                }
            }
        }
    }
}

@Composable
fun RootBlockedScreen(
    onDismissRootSim: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E0A0A))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.GppBad,
                contentDescription = "Root Detected",
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(80.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "ACCESS DENIED",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.error
            )

            Text(
                text = "Root / Jailbreak Compromise Detected",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(16.dp))

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Security Policy Enforced:\nThis application is restricted on rooted host OS devices to protect AES-256 cryptographic memory keys against unauthorized extraction.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White,
                    modifier = Modifier.padding(16.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = onDismissRootSim,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) {
                Text("DISMISS ROOT SIMULATION & UNBLOCK")
            }
        }
    }
}
