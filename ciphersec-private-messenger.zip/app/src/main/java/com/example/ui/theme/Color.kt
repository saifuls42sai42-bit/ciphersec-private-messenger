package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Ultra-Modern Cybersecurity Theme (Deep Black, Dark Navy Blue, Translucent Glass)
val CyberDarkBackground = Color(0xFF030712) // Deep Midnight Black
val CyberDarkSurface = Color(0xFF0F172A) // Dark Slate Navy Blue
val CyberDarkSurfaceVariant = Color(0xFF1E293B) // Dark Navy Variant

val CyberCyanPrimary = Color(0xFF00F0FF) // Neon Quantum Cyan
val CyberCyanSecondary = Color(0xFF0284C7) // Deep Cyan
val CyberGreenEncrypted = Color(0xFF10B981) // Emerald Shield Green
val CyberGoldAdmin = Color(0xFFF59E0B) // Super Admin Gold
val CyberRedAlert = Color(0xFFEF4444) // Intrusion Red

val CyberLightBackground = Color(0xFF090D16) // Default dark-first mode
val CyberLightSurface = Color(0xFF0F172A)
val CyberLightSurfaceVariant = Color(0xFF1E293B)

val BubbleOutgoingDark = Color(0xFF0284C7)
val BubbleIncomingDark = Color(0x331E293B)

val BubbleOutgoingLight = Color(0xFF0284C7)
val BubbleIncomingLight = Color(0x331E293B)

