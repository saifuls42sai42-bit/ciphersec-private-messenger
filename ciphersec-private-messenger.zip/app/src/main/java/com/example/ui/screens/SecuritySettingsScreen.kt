package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DeviceEntity
import com.example.data.LogSeverity
import com.example.data.SecurityLogEntity
import com.example.data.UserRole
import com.example.viewmodel.CipherViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecuritySettingsScreen(
    viewModel: CipherViewModel,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val isPasscodeLocked by viewModel.isPasscodeLocked.collectAsState()
    val activeDevices by viewModel.activeDevices.collectAsState()
    val securityLogs by viewModel.allSecurityLogs.collectAsState()

    var showFingerprintSasDialog by remember { mutableStateOf(false) }
    var showDeviceManagerDialog by remember { mutableStateOf(false) }
    var showCertPinningDialog by remember { mutableStateOf(false) }
    var showAuditLogDialog by remember { mutableStateOf(false) }
    var showChangePinDialog by remember { mutableStateOf(false) }
    var showTotpSecretDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Security & Settings", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // User Profile Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = currentUser?.name?.take(1)?.uppercase() ?: "C",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = currentUser?.name ?: "Unknown Operator",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                if (currentUser?.role == UserRole.SUPER_ADMIN) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = MaterialTheme.colorScheme.tertiary
                                    ) {
                                        Text(
                                            text = "SUPER ADMIN",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = currentUser?.email ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = currentUser?.clearanceLevel ?: "Clearance Level 3",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }

            // Cryptographic Vault Status Card
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Lock,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "CRYPTOGRAPHIC VAULT & TRANSPORT",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "• Storage: Room SQLCipher Local Database (AES-256-GCM)\n• Transport: TLS 1.3 Protocol with Domain Certificate Pinning\n• Key Exchange: Double Ratchet DH-4096 / Ephemeral Keys",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            item {
                Text(
                    text = "AUTHENTICATION & ACCESS",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                SettingsSwitchTile(
                    icon = Icons.Default.Fingerprint,
                    title = "Biometric & App Passcode Lock",
                    subtitle = "Require PIN / Biometric authentication on app open",
                    checked = isPasscodeLocked,
                    onCheckedChange = { viewModel.togglePasscodeLock(it) }
                )
            }

            item {
                SettingsTile(
                    icon = Icons.Default.Pin,
                    title = "Change Security PIN Code",
                    subtitle = "Update 4-digit master passcode for local app unlock",
                    onClick = { showChangePinDialog = true }
                )
            }

            item {
                val is2faOn = currentUser?.is2FaEnabled ?: false
                SettingsSwitchTile(
                    icon = Icons.Default.ShieldMoon,
                    title = "Two-Factor Authentication (2FA)",
                    subtitle = if (is2faOn) "TOTP Authenticator active" else "Require 6-digit TOTP code on login",
                    checked = is2faOn,
                    onCheckedChange = {
                        viewModel.toggle2FA(it)
                        if (it) showTotpSecretDialog = true
                    }
                )
            }

            item {
                Text(
                    text = "HARDENED SECURITY POLICIES",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
            }

            // PERFORMANCE, BATTERY & RESILIENCE ENGINE CARD
            item {
                val metrics by viewModel.performanceMetrics.collectAsState()

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Speed, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "PERFORMANCE & OFFLINE ENGINE",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Text(
                                    text = "OPTIMAL",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Cold App Start", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${metrics.bootTimeMs} ms", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                            Column {
                                Text("RAM Usage", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("%.1f MB".format(metrics.memoryUsageMb), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Offline Cache Hit", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${metrics.offlineCacheHitRate}%", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Low Battery Sync Budget", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Text("Batch requests & throttle background telemetry", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Button(
                                onClick = { viewModel.triggerBackgroundSync() },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("SYNC NOW", fontSize = 11.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Crash Recovery & Error Trap", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Text("Global handler logs exceptions safely to Room audit log", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            OutlinedButton(
                                onClick = { viewModel.triggerGarbageCollection() },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("PURGE RAM", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            item {
                val isScreenshotPrevented = currentUser?.preventScreenshots ?: true
                SettingsSwitchTile(
                    icon = Icons.Default.ScreenLockPortrait,
                    title = "Prevent Screen Capture (FLAG_SECURE)",
                    subtitle = "Block OS screenshot & screen recording capabilities",
                    checked = isScreenshotPrevented,
                    onCheckedChange = { viewModel.togglePreventScreenshots(it) }
                )
            }

            item {
                val isRootBlocked = currentUser?.blockRootedDevices ?: false
                SettingsSwitchTile(
                    icon = Icons.Default.BugReport,
                    title = "Block Rooted / Jailbroken Devices",
                    subtitle = "Enforce su binary & Magisk integrity policy checks",
                    checked = isRootBlocked,
                    onCheckedChange = { viewModel.toggleBlockRootedDevices(it) }
                )
            }

            item {
                val isCertPinningOn = currentUser?.isCertificatePinningEnabled ?: true
                SettingsSwitchTile(
                    icon = Icons.Default.Verified,
                    title = "TLS 1.3 Certificate Pinning",
                    subtitle = "Validate server public key SHA-256 fingerprint",
                    checked = isCertPinningOn,
                    onCheckedChange = { viewModel.toggleCertificatePinning(it) }
                )
            }

            item {
                Text(
                    text = "INSPECTOR & DEVICE MANAGEMENT",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                SettingsTile(
                    icon = Icons.Default.Devices,
                    title = "Active Device Sessions (${activeDevices.size})",
                    subtitle = "Manage trusted devices and terminate remote sessions",
                    onClick = { showDeviceManagerDialog = true }
                )
            }

            item {
                SettingsTile(
                    icon = Icons.Default.QrCodeScanner,
                    title = "Verify Safety Numbers (SAS)",
                    subtitle = "Compare Double Ratchet key fingerprints",
                    onClick = { showFingerprintSasDialog = true }
                )
            }

            item {
                SettingsTile(
                    icon = Icons.Default.Policy,
                    title = "Certificate Pinning Inspector",
                    subtitle = "View domain rules and sha256 cert hashes",
                    onClick = { showCertPinningDialog = true }
                )
            }

            item {
                SettingsTile(
                    icon = Icons.Default.ReceiptLong,
                    title = "Security Audit Event Logs (${securityLogs.size})",
                    subtitle = "View real-time authentication & security system logs",
                    onClick = { showAuditLogDialog = true }
                )
            }

            item {
                Text(
                    text = "PREFERENCES & APPEARANCE",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                SettingsSwitchTile(
                    icon = Icons.Default.DarkMode,
                    title = "High Contrast Dark Mode",
                    subtitle = "OLED Signal cybersecurity theme",
                    checked = isDarkMode,
                    onCheckedChange = { viewModel.toggleDarkMode() }
                )
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { viewModel.logout() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Logout, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("LOGOUT & WIPE SESSION CACHE", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // Safety Numbers Dialog
    if (showFingerprintSasDialog) {
        AlertDialog(
            onDismissRequest = { showFingerprintSasDialog = false },
            icon = { Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text("Safety Numbers (SAS)", fontWeight = FontWeight.Bold) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Scan or compare these numbers with team members to verify E2E Double Ratchet encryption integrity.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "39021  88402  10928  44029\n58392  10928  33029  11928",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showFingerprintSasDialog = false }) {
                    Text("Mark Verified")
                }
            }
        )
    }

    // Device Manager Dialog
    if (showDeviceManagerDialog) {
        AlertDialog(
            onDismissRequest = { showDeviceManagerDialog = false },
            icon = { Icon(Icons.Default.Devices, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text("Active Device Sessions", fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 350.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(activeDevices) { dev ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = dev.deviceName,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (dev.isCurrentDevice) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = MaterialTheme.colorScheme.primary
                                            ) {
                                                Text(
                                                    text = "THIS DEVICE",
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                    Text(
                                        text = "${dev.deviceType} • ${dev.ipAddress}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                if (!dev.isCurrentDevice) {
                                    IconButton(onClick = { viewModel.revokeDeviceSession(dev.id) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Revoke", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDeviceManagerDialog = false }) {
                    Text("CLOSE")
                }
            }
        )
    }

    // Cert Pinning Inspector Dialog
    if (showCertPinningDialog) {
        AlertDialog(
            onDismissRequest = { showCertPinningDialog = false },
            icon = { Icon(Icons.Default.Verified, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text("TLS 1.3 Certificate Pinning", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        text = "Network connections are pinned against the following SHA-256 public key hashes to prevent MITM attacks:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("Domain: api.ciphersec.team", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                            Text("sha256/AABBCC11223344556677889900AABBCC", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Domain: media.ciphersec.team", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                            Text("sha256/FFEEDD99887766554433221100FFEEDD", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCertPinningDialog = false }) {
                    Text("CLOSE")
                }
            }
        )
    }

    // Security Audit Log Viewer Dialog
    if (showAuditLogDialog) {
        val format = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        AlertDialog(
            onDismissRequest = { showAuditLogDialog = false },
            icon = { Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text("Security Audit Logs", fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(securityLogs) { log ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = log.eventType,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = when (log.severity) {
                                            LogSeverity.CRITICAL -> MaterialTheme.colorScheme.error
                                            LogSeverity.WARNING -> MaterialTheme.colorScheme.tertiary
                                            LogSeverity.INFO -> MaterialTheme.colorScheme.primary
                                        }
                                    )
                                    Text(
                                        text = format.format(Date(log.timestamp)),
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = log.details,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAuditLogDialog = false }) {
                    Text("CLOSE")
                }
            }
        )
    }

    // Change PIN Dialog
    if (showChangePinDialog) {
        var newPinText by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showChangePinDialog = false },
            title = { Text("Update Passcode PIN", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newPinText,
                    onValueChange = { if (it.length <= 4) newPinText = it },
                    label = { Text("New 4-Digit PIN") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPinText.length == 4) {
                            viewModel.updateSecurityPin(newPinText)
                            showChangePinDialog = false
                        }
                    },
                    enabled = newPinText.length == 4
                ) {
                    Text("SAVE PIN")
                }
            },
            dismissButton = {
                TextButton(onClick = { showChangePinDialog = false }) {
                    Text("CANCEL")
                }
            }
        )
    }

    // 2FA TOTP Secret Key Modal
    if (showTotpSecretDialog) {
        AlertDialog(
            onDismissRequest = { showTotpSecretDialog = false },
            icon = { Icon(Icons.Default.QrCode, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text("2FA Authenticator Setup", fontWeight = FontWeight.Bold) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Add this Secret Key to Google Authenticator, Aegis, or YubiKey:", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = currentUser?.totpSecret ?: "JBSWY3DPEHPK3PXP",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showTotpSecretDialog = false }) {
                    Text("DONE")
                }
            }
        )
    }
}

@Composable
private fun SettingsTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun SettingsSwitchTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}
