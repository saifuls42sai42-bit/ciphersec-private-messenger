package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.viewmodel.CipherViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: CipherViewModel,
    modifier: Modifier = Modifier
) {
    val users by viewModel.allUsers.collectAsState()
    val allDevices by viewModel.allDevices.collectAsState()
    val allChats by viewModel.allChats.collectAsState()
    val securityLogs by viewModel.allSecurityLogs.collectAsState()
    val customAppName by viewModel.customAppName.collectAsState()
    val customAppLogo by viewModel.customAppLogo.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }
    var showCreateUserDialog by remember { mutableStateOf(false) }
    var showCreateGroupDialog by remember { mutableStateOf(false) }
    var showBroadcastDialog by remember { mutableStateOf(false) }

    val tabs = listOf(
        "Users & IAM" to Icons.Default.People,
        "Devices" to Icons.Default.Devices,
        "Groups & Broadcast" to Icons.Default.Campaign,
        "Security Logs" to Icons.Default.ReceiptLong,
        "Storage & Backup" to Icons.Default.Storage,
        "System Settings" to Icons.Default.Settings
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = when (customAppLogo) {
                                        "ic_vault" -> Icons.Default.Lock
                                        "ic_quantum" -> Icons.Default.AutoAwesome
                                        "ic_badge" -> Icons.Default.Verified
                                        else -> Icons.Default.Shield
                                    },
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Super Admin Console",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "System: $customAppName • Single Authority Enforced",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.tertiary,
                                fontSize = 10.sp
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            if (selectedTab == 0) {
                FloatingActionButton(
                    onClick = { showCreateUserDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = "Add User Account")
                }
            } else if (selectedTab == 2) {
                FloatingActionButton(
                    onClick = { showCreateGroupDialog = true },
                    containerColor = MaterialTheme.colorScheme.secondary,
                    contentColor = MaterialTheme.colorScheme.onSecondary
                ) {
                    Icon(Icons.Default.GroupAdd, contentDescription = "Create Group Channel")
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Navigation Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 12.dp,
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ) {
                tabs.forEachIndexed { index, pair ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = pair.second,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(pair.first, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            }
                        }
                    )
                }
            }

            Box(modifier = Modifier.weight(1f)) {
                when (selectedTab) {
                    0 -> UsersTab(
                        users = users,
                        viewModel = viewModel,
                        onCreateUser = { showCreateUserDialog = true }
                    )
                    1 -> DevicesTab(
                        devices = allDevices,
                        users = users,
                        viewModel = viewModel
                    )
                    2 -> GroupsAndBroadcastTab(
                        chats = allChats,
                        users = users,
                        viewModel = viewModel,
                        onCreateGroup = { showCreateGroupDialog = true },
                        onBroadcast = { showBroadcastDialog = true }
                    )
                    3 -> SecurityLogsTab(
                        logs = securityLogs,
                        viewModel = viewModel
                    )
                    4 -> StorageAndBackupTab(
                        viewModel = viewModel
                    )
                    5 -> SystemSettingsTab(
                        appName = customAppName,
                        appLogo = customAppLogo,
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    if (showCreateUserDialog) {
        CreateUserAccountDialog(
            existingUsers = users,
            onDismiss = { showCreateUserDialog = false },
            onCreate = { name, email, pass, role, clearance ->
                viewModel.createNewUser(name, email, pass, role, clearance) { success, _ ->
                    if (success) showCreateUserDialog = false
                }
            }
        )
    }

    if (showCreateGroupDialog) {
        CreateGroupDialog(
            users = users,
            onDismiss = { showCreateGroupDialog = false },
            onCreate = { name, desc, members ->
                viewModel.createGroupChat(name, desc, members)
                showCreateGroupDialog = false
            }
        )
    }

    if (showBroadcastDialog) {
        BroadcastDialog(
            onDismiss = { showBroadcastDialog = false },
            onSend = { text ->
                viewModel.broadcastSystemMessage(text)
                showBroadcastDialog = false
            }
        )
    }
}

// TAB 0: USERS & IAM MANAGEMENT
@Composable
private fun UsersTab(
    users: List<UserEntity>,
    viewModel: CipherViewModel,
    onCreateUser: () -> Unit
) {
    var selectedUserForReset by remember { mutableStateOf<UserEntity?>(null) }
    var selectedUserForClearance by remember { mutableStateOf<UserEntity?>(null) }
    var selectedUserForDelete by remember { mutableStateOf<UserEntity?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.VerifiedUser,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.tertiary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SINGLE SUPER ADMIN POLICY ENFORCED",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.tertiary
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Only 1 Super Admin (Alex Vance) holds root authority over this system. New accounts are provisioned under strict clearance levels.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatItem(label = "Total Users", value = "${users.size}")
                        StatItem(label = "Active Team", value = "${users.count { !it.isSuspended }}")
                        StatItem(label = "Disabled", value = "${users.count { it.isSuspended }}")
                    }
                }
            }
        }

        item {
            Text(
                text = "IDENTITY ACCOUNTS (${users.size})",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold
            )
        }

        items(users, key = { it.id }) { user ->
            UserManagementCard(
                user = user,
                onToggleDisable = { viewModel.toggleUserSuspended(user) },
                onResetPassword = { selectedUserForReset = user },
                onChangeClearance = { selectedUserForClearance = user },
                onForceLogout = { viewModel.forceLogoutUserDevices(user.id, user.name) },
                onDelete = { selectedUserForDelete = user }
            )
        }
    }

    // Reset Password Dialog
    selectedUserForReset?.let { user ->
        ResetPasswordDialog(
            user = user,
            onDismiss = { selectedUserForReset = null },
            onConfirm = { newPass ->
                viewModel.resetUserPassword(user, newPass)
                selectedUserForReset = null
            }
        )
    }

    // Clearance Dialog
    selectedUserForClearance?.let { user ->
        EditClearanceDialog(
            user = user,
            onDismiss = { selectedUserForClearance = null },
            onConfirm = { newClearance ->
                viewModel.updateUserClearance(user, newClearance)
                selectedUserForClearance = null
            }
        )
    }

    // Delete User Dialog
    selectedUserForDelete?.let { user ->
        AlertDialog(
            onDismissRequest = { selectedUserForDelete = null },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Delete User Account?", fontWeight = FontWeight.Bold) },
            text = { Text("Permanently purge account for '${user.name}' (${user.email}) and terminate all associated sessions?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.removeUserAccount(user)
                        selectedUserForDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("PURGE ACCOUNT")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedUserForDelete = null }) {
                    Text("CANCEL")
                }
            }
        )
    }
}

@Composable
private fun UserManagementCard(
    user: UserEntity,
    onToggleDisable: () -> Unit,
    onResetPassword: () -> Unit,
    onChangeClearance: () -> Unit,
    onForceLogout: () -> Unit,
    onDelete: () -> Unit
) {
    val isSuperAdmin = user.role == UserRole.SUPER_ADMIN

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (user.isSuspended) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)
            else MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSuperAdmin) MaterialTheme.colorScheme.tertiary
            else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                if (isSuperAdmin) MaterialTheme.colorScheme.tertiary
                                else MaterialTheme.colorScheme.primaryContainer
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = user.name.take(1).uppercase(),
                            fontWeight = FontWeight.Bold,
                            color = if (isSuperAdmin) Color.Black else MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = user.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            if (isSuperAdmin) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = MaterialTheme.colorScheme.tertiary
                                ) {
                                    Text(
                                        text = "SUPER ADMIN",
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Black,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = user.email,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = user.clearanceLevel,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (user.isSuspended) MaterialTheme.colorScheme.error
                            else if (user.onlineStatus) Color(0xFF2E7D32)
                            else MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = if (user.isSuspended) "SUSPENDED" else if (user.onlineStatus) "ONLINE" else "OFFLINE",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            // Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = onResetPassword) {
                        Icon(Icons.Default.LockReset, contentDescription = "Reset Password", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onChangeClearance) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = "Manage Clearance", tint = MaterialTheme.colorScheme.secondary)
                    }
                    IconButton(onClick = onForceLogout) {
                        Icon(Icons.Default.PowerSettingsNew, contentDescription = "Force Logout", tint = MaterialTheme.colorScheme.tertiary)
                    }
                }

                if (!isSuperAdmin) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = onToggleDisable) {
                            Text(
                                text = if (user.isSuspended) "ENABLE" else "DISABLE",
                                color = if (user.isSuspended) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                        IconButton(onClick = onDelete) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete User", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}

// TAB 1: DEVICE MANAGEMENT & APPROVALS
@Composable
private fun DevicesTab(
    devices: List<DeviceEntity>,
    users: List<UserEntity>,
    viewModel: CipherViewModel
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Devices,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "REGISTERED DEVICE SESSIONS",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Approve new hardware keys, reject unauthorized endpoints, or revoke session tokens.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "ACTIVE ENDPOINTS (${devices.size})",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold
            )
        }

        if (devices.isEmpty()) {
            item {
                Text("No active devices detected.", style = MaterialTheme.typography.bodySmall)
            }
        } else {
            items(devices, key = { it.id }) { dev ->
                val owner = users.find { it.id == dev.userId }
                DeviceApprovalCard(
                    device = dev,
                    ownerName = owner?.name ?: "Unknown User",
                    onApprove = { viewModel.approveDevice(dev.id) },
                    onReject = { viewModel.rejectDevice(dev.id) }
                )
            }
        }
    }
}

@Composable
private fun DeviceApprovalCard(
    device: DeviceEntity,
    ownerName: String,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    val format = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault())

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (device.isVerified) MaterialTheme.colorScheme.outlineVariant
            else MaterialTheme.colorScheme.error
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = device.deviceName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (device.isVerified) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                    ) {
                        Text(
                            text = if (device.isVerified) "VERIFIED" else "PENDING APPROVAL",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
                Text(
                    text = "Owner: $ownerName • ${device.deviceType}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "IP: ${device.ipAddress} • Last Active: ${format.format(Date(device.lastActiveTimestamp))}",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (!device.isVerified) {
                    IconButton(onClick = onApprove) {
                        Icon(Icons.Default.CheckCircle, contentDescription = "Approve", tint = Color(0xFF2E7D32))
                    }
                }
                IconButton(onClick = onReject) {
                    Icon(Icons.Default.Cancel, contentDescription = "Reject / Revoke", tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

// TAB 2: GROUPS & BROADCAST MESSAGES
@Composable
private fun GroupsAndBroadcastTab(
    chats: List<ChatEntity>,
    users: List<UserEntity>,
    viewModel: CipherViewModel,
    onCreateGroup: () -> Unit,
    onBroadcast: () -> Unit
) {
    val groupChats = chats.filter { it.type == ChatType.GROUP }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "SYSTEM BROADCAST DISPATCHER",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Broadcast emergency security advisories or system policy updates simultaneously to all provisioned channels.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onBroadcast,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Campaign, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("DISPATCH BROADCAST ANNOUNCEMENT", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "GROUP CHANNELS (${groupChats.size})",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
                TextButton(onClick = onCreateGroup) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("CREATE GROUP")
                }
            }
        }

        items(groupChats, key = { it.id }) { chat ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Group, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(chat.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(chat.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    IconButton(onClick = { viewModel.deleteGroupChat(chat.id, chat.name) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete Group", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

// TAB 3: SECURITY LOGS & LOGIN HISTORY
@Composable
private fun SecurityLogsTab(
    logs: List<SecurityLogEntity>,
    viewModel: CipherViewModel
) {
    val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
    var filterType by remember { mutableStateOf("ALL") } // "ALL", "LOGIN"

    val filteredLogs = remember(logs, filterType) {
        if (filterType == "LOGIN") {
            logs.filter { it.eventType.contains("LOGIN") || it.eventType.contains("AUTH") || it.eventType.contains("2FA") }
        } else logs
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = filterType == "ALL",
                        onClick = { filterType = "ALL" },
                        label = { Text("All Logs (${logs.size})") }
                    )
                    FilterChip(
                        selected = filterType == "LOGIN",
                        onClick = { filterType = "LOGIN" },
                        label = { Text("Login History") }
                    )
                }

                TextButton(onClick = { viewModel.clearSecurityLogs() }) {
                    Text("CLEAR", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            }
        }

        items(filteredLogs, key = { it.id }) { log ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = log.eventType,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = when (log.severity) {
                                LogSeverity.CRITICAL -> MaterialTheme.colorScheme.error
                                LogSeverity.WARNING -> MaterialTheme.colorScheme.tertiary
                                LogSeverity.INFO -> MaterialTheme.colorScheme.primary
                            }
                        )
                        Text(
                            text = format.format(Date(log.timestamp)),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = log.details,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "IP Address: ${log.ipAddress}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

// TAB 4: STORAGE & BACKUP MANAGEMENT
@Composable
private fun StorageAndBackupTab(
    viewModel: CipherViewModel
) {
    var backupStatusText by remember { mutableStateOf<String?>(null) }
    var storageStatusText by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("LOCAL SQLCIPHER STORAGE USAGE", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    StorageProgressRow(label = "Encrypted SQLite Database", sizeMB = "12.4 MB", progress = 0.35f)
                    StorageProgressRow(label = "Media & Voice Attachments", sizeMB = "28.1 MB", progress = 0.65f)
                    StorageProgressRow(label = "Audit & Security Logs", sizeMB = "2.2 MB", progress = 0.15f)

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            viewModel.optimizeStorage { storageStatusText = it }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.CleaningServices, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("PURGE CACHE & COMPACT DATABASE (VACUUM)", fontWeight = FontWeight.Bold)
                    }

                    storageStatusText?.let {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("BACKUP & DISASTER RECOVERY", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Create encrypted local backups of room data or restore existing snapshot state.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = {
                                viewModel.createEncryptedBackup { backupStatusText = "Created $it" }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("CREATE BACKUP")
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.restoreEncryptedBackup("CIPHER_VAULT_BACKUP_SNAPSHOT.enc") { _, msg ->
                                    backupStatusText = msg
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("RESTORE BACKUP")
                        }
                    }

                    backupStatusText?.let {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
                    }
                }
            }
        }
    }
}

@Composable
private fun StorageProgressRow(label: String, sizeMB: String, progress: Float) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodySmall)
            Text(sizeMB, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
            color = MaterialTheme.colorScheme.primary
        )
    }
}

// TAB 5: SYSTEM SETTINGS, LOGO & APP NAME
@Composable
private fun SystemSettingsTab(
    appName: String,
    appLogo: String,
    viewModel: CipherViewModel
) {
    var editAppNameText by remember { mutableStateOf(appName) }
    var selectedLogo by remember { mutableStateOf(appLogo) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("SYSTEM BRANDING & IDENTITY", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = editAppNameText,
                        onValueChange = { editAppNameText = it },
                        label = { Text("App System Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        trailingIcon = {
                            IconButton(onClick = { viewModel.updateAppName(editAppNameText) }) {
                                Icon(Icons.Default.Save, contentDescription = "Save Name")
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("SELECT SYSTEM APP LOGO BADGE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        LogoOptionItem(
                            icon = Icons.Default.Shield,
                            label = "Shield",
                            selected = selectedLogo == "ic_shield",
                            onClick = {
                                selectedLogo = "ic_shield"
                                viewModel.updateAppLogo("ic_shield")
                            }
                        )
                        LogoOptionItem(
                            icon = Icons.Default.Lock,
                            label = "Vault",
                            selected = selectedLogo == "ic_vault",
                            onClick = {
                                selectedLogo = "ic_vault"
                                viewModel.updateAppLogo("ic_vault")
                            }
                        )
                        LogoOptionItem(
                            icon = Icons.Default.AutoAwesome,
                            label = "Quantum",
                            selected = selectedLogo == "ic_quantum",
                            onClick = {
                                selectedLogo = "ic_quantum"
                                viewModel.updateAppLogo("ic_quantum")
                            }
                        )
                        LogoOptionItem(
                            icon = Icons.Default.Verified,
                            label = "Verified",
                            selected = selectedLogo == "ic_badge",
                            onClick = {
                                selectedLogo = "ic_badge"
                                viewModel.updateAppLogo("ic_badge")
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LogoOptionItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        border = if (selected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun StatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
    }
}

// DIALOGS
@Composable
private fun CreateUserAccountDialog(
    existingUsers: List<UserEntity>,
    onDismiss: () -> Unit,
    onCreate: (name: String, email: String, pass: String, role: UserRole, clearance: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("CipherSec123!") }
    var clearance by remember { mutableStateOf("Level 3 - Security Analyst") }
    var isSuperAdminAttempt by remember { mutableStateOf(false) }

    val hasExistingAdmin = existingUsers.any { it.role == UserRole.SUPER_ADMIN }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Provision Cybersecurity Account", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Team Email Address") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = pass,
                    onValueChange = { pass = it },
                    label = { Text("Temporary Passcode") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = clearance,
                    onValueChange = { clearance = it },
                    label = { Text("Clearance Level & Role") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { isSuperAdminAttempt = !isSuperAdminAttempt }
                ) {
                    Checkbox(checked = isSuperAdminAttempt, onCheckedChange = { isSuperAdminAttempt = it })
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Grant Super Admin Authority", fontSize = 12.sp)
                }

                if (isSuperAdminAttempt && hasExistingAdmin) {
                    Text(
                        text = "⚠️ Policy Warning: Single Super Admin rule is enforced. Alex Vance is already Super Admin. This account will automatically fall back to Team Member.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 10.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank() && email.isNotBlank() && pass.isNotBlank()) {
                        val role = if (isSuperAdminAttempt && !hasExistingAdmin) UserRole.SUPER_ADMIN else UserRole.TEAM_MEMBER
                        onCreate(name, email, pass, role, clearance)
                    }
                }
            ) {
                Text("Provision Account")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun ResetPasswordDialog(
    user: UserEntity,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var newPass by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Reset Password for ${user.name}", fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = newPass,
                onValueChange = { newPass = it },
                label = { Text("New Passcode") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (newPass.isNotBlank()) onConfirm(newPass)
                },
                enabled = newPass.isNotBlank()
            ) {
                Text("RESET PASSWORD")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL")
            }
        }
    )
}

@Composable
private fun EditClearanceDialog(
    user: UserEntity,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var clearanceText by remember { mutableStateOf(user.clearanceLevel) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Manage Clearance Level", fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = clearanceText,
                onValueChange = { clearanceText = it },
                label = { Text("Clearance & Permissions Role") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (clearanceText.isNotBlank()) onConfirm(clearanceText)
                }
            ) {
                Text("UPDATE CLEARANCE")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL")
            }
        }
    )
}

@Composable
private fun CreateGroupDialog(
    users: List<UserEntity>,
    onDismiss: () -> Unit,
    onCreate: (name: String, desc: String, members: List<String>) -> Unit
) {
    var groupName by remember { mutableStateOf("") }
    var groupDesc by remember { mutableStateOf("") }
    val selectedMembers = remember { mutableStateListOf<String>() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Provision New Group Channel", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = groupName,
                    onValueChange = { groupName = it },
                    label = { Text("Group Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = groupDesc,
                    onValueChange = { groupDesc = it },
                    label = { Text("Topic / Description") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Select Initial Members:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)

                LazyColumn(modifier = Modifier.heightIn(max = 180.dp)) {
                    items(users) { u ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (selectedMembers.contains(u.id)) selectedMembers.remove(u.id)
                                    else selectedMembers.add(u.id)
                                }
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(
                                checked = selectedMembers.contains(u.id),
                                onCheckedChange = {
                                    if (it) selectedMembers.add(u.id) else selectedMembers.remove(u.id)
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(u.name, fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (groupName.isNotBlank()) onCreate(groupName, groupDesc, selectedMembers.toList())
                },
                enabled = groupName.isNotBlank()
            ) {
                Text("CREATE CHANNEL")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL")
            }
        }
    )
}

@Composable
private fun BroadcastDialog(
    onDismiss: () -> Unit,
    onSend: (String) -> Unit
) {
    var broadcastText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dispatch System Broadcast", fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = broadcastText,
                onValueChange = { broadcastText = it },
                label = { Text("System Announcement / Alert Text") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (broadcastText.isNotBlank()) onSend(broadcastText)
                },
                enabled = broadcastText.isNotBlank()
            ) {
                Text("DISPATCH BROADCAST")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL")
            }
        }
    )
}
