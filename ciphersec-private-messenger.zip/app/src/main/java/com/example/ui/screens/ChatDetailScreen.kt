package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.*
import com.example.viewmodel.CipherViewModel
import com.example.viewmodel.SelectedMedia
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailScreen(
    viewModel: CipherViewModel,
    chatId: String,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val chats by viewModel.allChats.collectAsState()
    val chat = chats.find { it.id == chatId }
    val messages by viewModel.currentChatMessages.collectAsState()
    val pinnedMessage by viewModel.currentPinnedMessage.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val replyingToMessage by viewModel.replyingToMessage.collectAsState()
    val editingMessage by viewModel.editingMessage.collectAsState()
    val typingMap by viewModel.typingStatusMap.collectAsState()

    var inputText by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var showAttachmentSheet by remember { mutableStateOf(false) }
    var isRecordingVoice by remember { mutableStateOf(false) }
    var voiceRecordDuration by remember { mutableStateOf(0) }
    var selectedMessageForAction by remember { mutableStateOf<MessageEntity?>(null) }

    val typingText = typingMap[chatId]

    LaunchedEffect(editingMessage) {
        if (editingMessage != null) {
            inputText = editingMessage?.text ?: ""
        }
    }

    LaunchedEffect(isRecordingVoice) {
        if (isRecordingVoice) {
            voiceRecordDuration = 0
            while (isRecordingVoice) {
                delay(1000)
                voiceRecordDuration++
            }
        }
    }

    val displayMessages = if (searchQuery.isNotBlank()) {
        messages.filter { it.text.contains(searchQuery, ignoreCase = true) || it.fileName.contains(searchQuery, ignoreCase = true) }
    } else {
        messages
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    if (isSearchActive) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search in chat...") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            trailingIcon = {
                                IconButton(onClick = { isSearchActive = false; searchQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "Close Search")
                                }
                            }
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (chat?.type == ChatType.GROUP) MaterialTheme.colorScheme.primaryContainer
                                        else MaterialTheme.colorScheme.secondaryContainer
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = chat?.name?.take(1)?.uppercase() ?: "C",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = chat?.name ?: "Chat Channel",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = typingText ?: "🛡️ E2E Encrypted • Online",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (typingText != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                },
                actions = {
                    if (!isSearchActive) {
                        IconButton(onClick = { isSearchActive = true }) {
                            Icon(Icons.Default.Search, contentDescription = "Search Chat")
                        }
                        IconButton(onClick = {
                            viewModel.startVoiceCall(
                                chatId,
                                chat?.name ?: "Team Call",
                                isGroup = chat?.type == ChatType.GROUP
                            )
                        }) {
                            Icon(Icons.Default.Call, contentDescription = "Voice Call")
                        }
                        IconButton(onClick = {
                            viewModel.startVideoCall(
                                chatId,
                                chat?.name ?: "Team Video Call",
                                isGroup = chat?.type == ChatType.GROUP
                            )
                        }) {
                            Icon(Icons.Default.Videocam, contentDescription = "Video Call")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            Column(modifier = Modifier.background(MaterialTheme.colorScheme.surface)) {
                // Threaded Reply Bar Preview
                AnimatedVisibility(visible = replyingToMessage != null) {
                    val reply = replyingToMessage
                    if (reply != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(modifier = Modifier.weight(1f)) {
                                    Box(
                                        modifier = Modifier
                                            .width(4.dp)
                                            .height(36.dp)
                                            .background(MaterialTheme.colorScheme.primary)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "Replying to ${reply.senderName}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = reply.text.take(50),
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                IconButton(onClick = { viewModel.setReplyingTo(null) }) {
                                    Icon(Icons.Default.Close, contentDescription = "Cancel reply")
                                }
                            }
                        }
                    }
                }

                // Editing Indicator
                AnimatedVisibility(visible = editingMessage != null) {
                    Surface(
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Editing message...",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                            IconButton(onClick = { viewModel.setEditingMessage(null); inputText = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Cancel Edit")
                            }
                        }
                    }
                }

                // Voice Recording Bar or Standard Input Row
                if (isRecordingVoice) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Recording",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = String.format("Recording Voice: 00:%02d", voiceRecordDuration),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                        }

                        Row {
                            TextButton(onClick = { isRecordingVoice = false }) {
                                Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Button(
                                onClick = {
                                    viewModel.sendMessage(
                                        text = "Voice message (${voiceRecordDuration}s)",
                                        mediaType = MediaType.VOICE,
                                        durationMs = voiceRecordDuration * 1000L
                                    )
                                    isRecordingVoice = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Text("Send Voice")
                            }
                        }
                    }
                } else {
                    // Standard Input Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { showAttachmentSheet = true }) {
                            Icon(Icons.Default.AttachFile, contentDescription = "Attach Media", tint = MaterialTheme.colorScheme.primary)
                        }

                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            placeholder = { Text("Type encrypted message...") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(24.dp),
                            maxLines = 4
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        if (inputText.isNotBlank()) {
                            FloatingActionButton(
                                onClick = {
                                    viewModel.sendMessage(inputText)
                                    inputText = ""
                                },
                                modifier = Modifier.size(48.dp),
                                containerColor = MaterialTheme.colorScheme.primary
                            ) {
                                Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.Black)
                            }
                        } else {
                            FloatingActionButton(
                                onClick = { isRecordingVoice = true },
                                modifier = Modifier.size(48.dp),
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Icon(Icons.Default.Mic, contentDescription = "Record Voice", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Pinned Message Banner Header
            if (pinnedMessage != null) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            // Quick jump
                        }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.PushPin,
                            contentDescription = "Pinned",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Pinned Message by ${pinnedMessage?.senderName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = pinnedMessage?.text ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // Message List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                reverseLayout = false
            ) {
                items(displayMessages, key = { it.id }) { msg ->
                    val isMine = msg.senderId == currentUser?.id
                    MessageBubble(
                        message = msg,
                        isMine = isMine,
                        currentUserId = currentUser?.id ?: "",
                        onMediaClick = { uri, type, title ->
                            viewModel.setMediaPreview(SelectedMedia(uri, type, title))
                        },
                        onLongClick = { selectedMessageForAction = msg },
                        onReactionClick = { emoji ->
                            viewModel.toggleReaction(msg, emoji)
                        }
                    )
                }
            }
        }
    }

    // Media Attachment Dialog
    if (showAttachmentSheet) {
        AlertDialog(
            onDismissRequest = { showAttachmentSheet = false },
            title = { Text("Encrypted Media Attachment") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    AttachmentOptionRow(
                        icon = Icons.Default.CameraAlt,
                        title = "Take Photo / Video",
                        subtitle = "Capture securely with camera",
                        onClick = {
                            viewModel.sendMessage(
                                text = "Security camera photo capture",
                                mediaType = MediaType.IMAGE,
                                mediaUri = "img_sample_media1"
                            )
                            showAttachmentSheet = false
                        }
                    )
                    AttachmentOptionRow(
                        icon = Icons.Default.PhotoLibrary,
                        title = "Select from Gallery",
                        subtitle = "Attach media files",
                        onClick = {
                            viewModel.sendMessage(
                                text = "Gallery threat diagram snapshot",
                                mediaType = MediaType.IMAGE,
                                mediaUri = "img_sample_media1"
                            )
                            showAttachmentSheet = false
                        }
                    )
                    AttachmentOptionRow(
                        icon = Icons.Default.PictureAsPdf,
                        title = "Send PDF / Classified Document",
                        subtitle = "Attach reports or malware analyses",
                        onClick = {
                            viewModel.sendMessage(
                                text = "Classified Threat Intelligence Report",
                                mediaType = MediaType.PDF,
                                fileName = "Threat_Intel_Report_v4.pdf",
                                fileSize = "4.2 MB"
                            )
                            showAttachmentSheet = false
                        }
                    )
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showAttachmentSheet = false }) { Text("Close") }
            }
        )
    }

    // Message Options Context Sheet
    selectedMessageForAction?.let { msg ->
        val isMine = msg.senderId == currentUser?.id
        AlertDialog(
            onDismissRequest = { selectedMessageForAction = null },
            title = { Text("Message Actions") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Quick Reactions Row
                    Text("QUICK REACTIONS:", style = MaterialTheme.typography.labelSmall)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf("👍", "❤️", "🔒", "🔥", "⚡", "🚀", "💬", "🛡️").forEach { emoji ->
                            Text(
                                text = emoji,
                                fontSize = 22.sp,
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .clickable {
                                        viewModel.toggleReaction(msg, emoji)
                                        selectedMessageForAction = null
                                    }
                                    .padding(4.dp)
                            )
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 8.dp))

                    TextButton(
                        onClick = {
                            viewModel.setReplyingTo(msg)
                            selectedMessageForAction = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Reply, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Reply Message")
                    }

                    TextButton(
                        onClick = {
                            viewModel.togglePinMessage(msg)
                            selectedMessageForAction = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PushPin, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (msg.isPinned) "Unpin Message" else "Pin Message to Header")
                    }

                    if (isMine) {
                        TextButton(
                            onClick = {
                                viewModel.setEditingMessage(msg)
                                selectedMessageForAction = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Edit Message")
                        }
                    }

                    TextButton(
                        onClick = {
                            viewModel.deleteMessage(msg, forEveryone = true)
                            selectedMessageForAction = null
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Delete Message")
                    }
                }
            },
            confirmButton = {}
        )
    }
}

@Composable
private fun MessageBubble(
    message: MessageEntity,
    isMine: Boolean,
    currentUserId: String,
    onMediaClick: (String, MediaType, String) -> Unit,
    onLongClick: () -> Unit,
    onReactionClick: (String) -> Unit
) {
    val formatter = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val timeStr = formatter.format(Date(message.timestamp))

    val bubbleColor = if (isMine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    val textColor = if (isMine) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalAlignment = if (isMine) Alignment.End else Alignment.Start
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isMine) 16.dp else 4.dp,
                bottomEnd = if (isMine) 4.dp else 16.dp
            ),
            color = bubbleColor,
            modifier = Modifier
                .widthIn(max = 290.dp)
                .clickable { onLongClick() }
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                // Sender Name if in group & not mine
                if (!isMine) {
                    Text(
                        text = message.senderName,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                }

                // Threaded Reply Header if present
                if (message.replyToMessageId != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.Black.copy(alpha = 0.15f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                    ) {
                        Row(modifier = Modifier.padding(6.dp)) {
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(28.dp)
                                    .background(MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = message.replyToSenderName ?: "",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = message.replyToText ?: "",
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }

                // Media Attachment Display
                when (message.mediaType) {
                    MediaType.IMAGE -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    onMediaClick(message.mediaUri, MediaType.IMAGE, message.text)
                                }
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_sample_media1),
                                contentDescription = "Attached image",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                    MediaType.VIDEO -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.Black)
                                .clickable {
                                    onMediaClick(message.mediaUri, MediaType.VIDEO, message.text)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayCircle,
                                contentDescription = "Play Video",
                                tint = Color.White,
                                modifier = Modifier.size(48.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                    MediaType.DOCUMENT, MediaType.PDF -> {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onMediaClick(message.fileName, message.mediaType, message.fileName)
                                },
                            colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.2f)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PictureAsPdf,
                                    contentDescription = "PDF",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = message.fileName.ifEmpty { "Attachment.pdf" },
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = message.fileSize.ifEmpty { "2.4 MB" },
                                        fontSize = 10.sp,
                                        color = Color.LightGray
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                    MediaType.VOICE -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            IconButton(
                                onClick = { /* Play voice note */ },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play Voice Note", tint = Color.Black)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            // Waveform bars simulation
                            Row(
                                modifier = Modifier.weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                listOf(12, 24, 18, 30, 16, 28, 14, 22, 10, 20).forEach { heightDp ->
                                    Box(
                                        modifier = Modifier
                                            .width(3.dp)
                                            .height(heightDp.dp)
                                            .background(MaterialTheme.colorScheme.primary)
                                    )
                                }
                            }
                        }
                    }
                    else -> {}
                }

                // Message Text
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = textColor
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Time & Status Row
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (message.isEdited) {
                        Text(
                            text = "(edited) ",
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 9.sp,
                            color = textColor.copy(alpha = 0.6f)
                        )
                    }
                    Text(
                        text = timeStr,
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        color = textColor.copy(alpha = 0.6f)
                    )
                    if (isMine) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.DoneAll,
                            contentDescription = "Read",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }

        // Reactions Display under Bubble
        val reactionsMap = try {
            val obj = JSONObject(message.reactionsJson)
            val keys = obj.keys()
            val map = mutableMapOf<String, Int>()
            while (keys.hasNext()) {
                val key = keys.next()
                val arr = obj.optJSONArray(key)
                if (arr != null && arr.length() > 0) {
                    map[key] = arr.length()
                }
            }
            map
        } catch (e: Exception) {
            emptyMap()
        }

        if (reactionsMap.isNotEmpty()) {
            Row(
                modifier = Modifier.padding(top = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                reactionsMap.forEach { (emoji, count) ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.clickable { onReactionClick(emoji) }
                    ) {
                        Text(
                            text = "$emoji $count",
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AttachmentOptionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
