package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CyberCyanPrimary,
    onPrimary = Color.Black,
    primaryContainer = CyberCyanSecondary,
    onPrimaryContainer = Color.White,
    secondary = CyberGreenEncrypted,
    onSecondary = Color.Black,
    tertiary = CyberGoldAdmin,
    background = CyberDarkBackground,
    onBackground = Color(0xFFF3F4F6),
    surface = CyberDarkSurface,
    onSurface = Color(0xFFF9FAFB),
    surfaceVariant = CyberDarkSurfaceVariant,
    onSurfaceVariant = Color(0xFF9CA3AF),
    error = CyberRedAlert,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = CyberCyanSecondary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F2FE),
    onPrimaryContainer = Color(0xFF0369A1),
    secondary = CyberGreenEncrypted,
    onSecondary = Color.White,
    tertiary = CyberGoldAdmin,
    background = CyberLightBackground,
    onBackground = Color(0xFF0F172A),
    surface = CyberLightSurface,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = CyberLightSurfaceVariant,
    onSurfaceVariant = Color(0xFF475569),
    error = CyberRedAlert,
    onError = Color.White
)

@Composable
fun CipherSecTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
