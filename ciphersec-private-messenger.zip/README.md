# CipherSec Private Messenger - System Architecture & Technical Documentation

**CipherSec Private Messenger** is an enterprise-grade, ultra-secure, zero-trust private communications platform engineered for cybersecurity operations teams, threat intelligence analysts, and executive incident response units.

---

## 🏛️ System Architecture Overview

CipherSec is built with **Modern Android Jetpack Compose**, **Kotlin Coroutines / Flow**, **Room SQLCipher-backed local persistence**, and **Clean Architecture (MVVM)**.

```
+-------------------------------------------------------------------------+
|                        Jetpack Compose UI Layer                         |
|   AdminDashboard | ChatList | ChatDetail | SecuritySettings | MediaViewer|
+-------------------------------------------------------------------------+
                                    |
                                    v
+-------------------------------------------------------------------------+
|                          CipherViewModel Layer                          |
|  StateFlows | User Auth | Session Tokens | Device Approval | Broadcasts |
+-------------------------------------------------------------------------+
                                    |
                                    v
+-------------------------------------------------------------------------+
|                           CipherRepository                              |
|   MessageEncryption (AES-256-GCM) | Offline Media Cache | System Audit |
+-------------------------------------------------------------------------+
                                    |
                                    v
+-------------------------------------------------------------------------+
|                       AppDatabase (Room Database)                       |
|   13 Secure Tables: Users, Devices, Sessions, Messages, Groups,         |
|   Group Members, Calls, Voice Messages, Media Files, Documents,         |
|   Notifications, Audit Logs, Settings                                   |
+-------------------------------------------------------------------------+
```

---

## 🗄️ Backend Database Schema (13 Room Entities)

Every table is backed by Room DAOs with Flow streams and reactive updates:

1. **`users`** (`UserEntity`): Identity accounts, role (`SUPER_ADMIN`, `TEAM_MEMBER`), clearance level, biometric status, certificate pinning state, suspension flag.
2. **`devices`** (`DeviceEntity`): Hardware endpoints, hardware key fingerprint, IP address, verification status, last active timestamp.
3. **`sessions`** (`SessionEntity`): Active auth sessions, device binding tokens, expiration timestamps, active flags.
4. **`messages`** (`MessageEntity`): **Pre-storage AES-256-GCM Encrypted** text payloads, sender/chat IDs, media attachments, delivery status (`SENDING`, `SENT`, `DELIVERED`, `READ`), reaction JSONs.
5. **`groups`** (`GroupEntity`): Group channel parameters, encryption status, creator ID, member limits.
6. **`group_members`** (`GroupMemberEntity`): User-to-Group junction table with role attributes (`ADMIN`, `MODERATOR`, `MEMBER`).
7. **`calls`** (`CallEntity`): Voice/Video call sessions, duration, status (`COMPLETED`, `MISSED`, `DECLINED`).
8. **`voice_messages`** (`VoiceMessageEntity`): Audio clip references, duration, sampling rate, waveform visualizer data.
9. **`media_files`** (`MediaFileEntity`): Image/video attachments, dimensions, file size, SHA-256 checksums.
10. **`documents`** (`DocumentEntity`): Encrypted PDF/file attachments, storage URIs, file extension, encryption hashes.
11. **`notifications`** (`NotificationEntity`): In-app system advisories, broadcast announcements, read status.
12. **`audit_logs`** (`AuditLogEntity`): System security events, actor user ID, severity (`INFO`, `WARNING`, `CRITICAL`), IP address.
13. **`settings`** (`SettingsEntity`): System configuration key-value storage, branding badges, app custom titles.

---

## 🔒 Security & Cryptographic Blueprint

- **Pre-Storage AES-256-GCM Encryption**: All chat messages undergo hardware-assisted GCM encryption before hitting SQLite storage (`MessageEncryption.kt`). Plaintext never touches disk unencrypted.
- **Single Super Admin Enforcer**: Strict authority constraint ensuring exactly 1 Super Admin account (Alex Vance) exists. Any attempt to provision secondary Super Admins automatically defaults to standard Team Member role.
- **Zero-Trust Device Management**: Hardware endpoints require Super Admin approval before accessing team channels. Session revoking instantly purges token validity.
- **Biometric & PIN Lockout**: Support for auto-lock timeouts, screenshot prevention (`FLAG_SECURE`), and certificate pinning toggles.

---

## ⚡ Performance & Resilience Engine

- **Cold Boot Performance**: Sub-200ms initial app startup monitored by `AppPerformanceMonitor`.
- **LruCache Offline Media Engine**: 16MB in-memory LRU bitmap cache for instant thumbnail loading without disk IO stalls.
- **Uncaught Exception Crash Recovery**: `CrashRecoveryHandler` traps fatal uncaught exceptions and safely records details into Room audit logs before graceful recovery.
- **Low-Battery Sync Budget**: Throttled background sync mode for power efficiency.

---

## 🎨 UI & Aesthetics

- **Style**: Ultra-Modern Glassmorphism with pitch-black (`#030712`) and slate navy (`#0F172A`) dark gradients, neon cyan (`#00F0FF`) accents, rounded corners (`20.dp`), and fluid entry transitions.
