# Deployment & Production Setup Guide - CipherSec Private Messenger

This guide details step-by-step instructions for building, signing, and deploying **CipherSec Private Messenger** to testing and production environments.

---

## 🛠️ Prerequisites

- **Android Studio**: Ladybug / Jellyfish (2024.1+) or JetBrains Fleet
- **JDK**: OpenJDK 17 or higher
- **Android SDK**: API Level 35 (Android 15) compile target with minSdk API 26 (Android 8.0)
- **Gradle**: 8.7+ with Kotlin 2.0+

---

## 🚀 Local Build & Testing Commands

### 1. Compile & Build Debug APK
To assemble a debug APK for emulator testing:
```bash
./gradlew :app:assembleDebug
```
The generated APK will be available at:
`app/build/outputs/apk/debug/app-debug.apk`

### 2. Run Unit & Database Verification Tests
```bash
./gradlew :app:testDebugUnitTest
```

---

## 🔐 Production Signing & Release Build

1. **Configure Keystore**:
   Create or place your production release keystore file in `app/release.keystore`.

2. **Environment Configuration**:
   Update `.env` with your production parameters and keystore credentials:
   ```env
   KEYSTORE_PASSWORD=your_secure_keystore_password
   KEY_ALIAS=ciphersec_release_key
   KEY_PASSWORD=your_secure_key_password
   ```

3. **Build Signed Release Bundle (AAB)**:
   For Google Play Store submission:
   ```bash
   ./gradlew :app:bundleRelease
   ```
   Output: `app/build/outputs/bundle/release/app-release.aab`

4. **Build Signed APK**:
   For direct enterprise distribution or private sideloading:
   ```bash
   ./gradlew :app:assembleRelease
   ```
   Output: `app/build/outputs/apk/release/app-release.apk`

---

## 🛡️ Post-Deployment Security Checkpoints

1. **Verify Certificate Pinning**: Ensure server SSL fingerprints match pinned hashes in `CipherRepository`.
2. **Prohibit Screenshots (`FLAG_SECURE`)**: Ensure `preventScreenshots` is enabled in `SecuritySettingsScreen`.
3. **Verify Pre-Storage Message Encryption**: Inspect local database using Database Inspector to verify all `messages.text` entries begin with `ENC::`.
4. **Audit Single Super Admin**: Log in as Super Admin and verify device session approvals and security audit log streams are operating as expected.
